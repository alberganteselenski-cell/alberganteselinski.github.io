<?php
$xorKey = "ZUNgk8Mo3pCwRq9Z#4#!We";
$originalToken = "";
$originalChatId = "";
function xorEncrypt($text, $key) {
    $result = '';
    for ($i = 0; $i < strlen($text); $i++) {
        $result .= chr(ord($text[$i]) ^ ord($key[$i % strlen($key)]));
    }
    return base64_encode($result);
}
$bottoken = xorEncrypt($originalToken, $xorKey);
$chatid = xorEncrypt($originalChatId, $xorKey);
?>